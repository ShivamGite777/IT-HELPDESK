-- Helpdesk Database Schema for ABC Tech Pvt Ltd
-- This script creates all necessary tables for the smart helpdesk system

CREATE DATABASE IF NOT EXISTS helpdesk_db;
USE helpdesk_db;

-- Users Table (Employees, Technicians, Admin)
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Employee', 'Technician', 'Admin') NOT NULL,
    department VARCHAR(50),
    skill VARCHAR(50), -- For technicians (Network, Hardware, Software, Security)
    phone VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tickets Table
CREATE TABLE IF NOT EXISTS tickets (
    ticket_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('Hardware', 'Software', 'Network', 'Security', 'General') DEFAULT 'General',
    priority ENUM('Low', 'Medium', 'High') DEFAULT 'Low',
    status ENUM('Open', 'In Progress', 'Resolved', 'Closed') DEFAULT 'Open',
    assigned_to INT,
    department VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (employee_id) REFERENCES users(user_id),
    FOREIGN KEY (assigned_to) REFERENCES users(user_id)
);

-- Ticket Activity/Comments Table
CREATE TABLE IF NOT EXISTS ticket_activity (
    activity_id INT PRIMARY KEY AUTO_INCREMENT,
    ticket_id INT NOT NULL,
    user_id INT NOT NULL,
    activity TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Insert Sample Admin User
-- Password: admin123
INSERT INTO users (name, email, password, role, department) VALUES
('Admin User', 'admin@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Admin', 'IT');

-- Insert Sample Technicians
-- Password: tech123
INSERT INTO users (name, email, password, role, department, skill) VALUES
('John Technician', 'john.tech@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Technician', 'IT', 'Network'),
('Sarah Hardware', 'sarah.tech@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Technician', 'IT', 'Hardware'),
('Mike Software', 'mike.tech@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Technician', 'IT', 'Software'),
('Lisa Security', 'lisa.tech@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Technician', 'IT', 'Security');

-- Insert Sample Employees
-- Password: emp123
INSERT INTO users (name, email, password, role, department) VALUES
('Alice Employee', 'alice@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Employee', 'Sales'),
('Bob Employee', 'bob@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Employee', 'Marketing'),
('Carol Employee', 'carol@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Employee', 'HR'),
('David Employee', 'david@abctech.com', 'scrypt:32768:8:1$kQZGXMZzpyDejl1v$9eb5e13c6c5e6d5f8a5e3c8f8a6c2d7e9f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b', 'Employee', 'Finance');

-- Insert Sample Tickets (for demonstration)
INSERT INTO tickets (employee_id, title, description, category, priority, status, assigned_to, department) VALUES
(5, 'WiFi Not Working', 'My laptop is not connecting to office WiFi since morning. Urgent help needed.', 'Network', 'High', 'Open', 2, 'Sales'),
(6, 'Printer Issue', 'The printer on 3rd floor is not printing. Shows paper jam error.', 'Hardware', 'Medium', 'In Progress', 3, 'Marketing'),
(7, 'MS Office Installation', 'Need MS Office installed on my new laptop.', 'Software', 'Low', 'Open', 4, 'HR'),
(8, 'Password Reset', 'I forgot my email password and cannot access my account.', 'Security', 'High', 'Open', 5, 'Finance');

-- Create indexes for better performance
CREATE INDEX idx_tickets_employee ON tickets(employee_id);
CREATE INDEX idx_tickets_assigned ON tickets(assigned_to);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_priority ON tickets(priority);
CREATE INDEX idx_activity_ticket ON ticket_activity(ticket_id);
