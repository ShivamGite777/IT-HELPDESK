"""
Database Setup Script for ABC Tech Helpdesk
This script creates the database and populates it with sample data
"""

import mysql.connector
from werkzeug.security import generate_password_hash
from datetime import datetime

def create_database():
    """Create the helpdesk database and tables"""
    
    # Connect to MySQL server
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password'  # Change this to your MySQL root password
    )
    cursor = conn.cursor()
    
    # Create database
    cursor.execute("CREATE DATABASE IF NOT EXISTS helpdesk_db")
    cursor.execute("USE helpdesk_db")
    
    # Create users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('Employee', 'Technician', 'Admin') NOT NULL,
            department VARCHAR(50),
            skill VARCHAR(50),
            phone VARCHAR(15),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create tickets table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            ticket_id INT PRIMARY KEY AUTO_INCREMENT,
            employee_id INT NOT NULL,
            title VARCHAR(200) NOT NULL,
            description TEXT NOT NULL,
            category ENUM('Hardware', 'Software', 'Network', 'Security', 'General') DEFAULT 'General',
            priority ENUM('Low', 'Medium', 'High') DEFAULT 'Low',
            status ENUM('Open', 'In Progress', 'Resolved', 'Closed') DEFAULT 'Open',
            assigned_to INT,
            department VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            resolved_at TIMESTAMP NULL,
            FOREIGN KEY (employee_id) REFERENCES users(user_id),
            FOREIGN KEY (assigned_to) REFERENCES users(user_id)
        )
    """)
    
    # Create ticket_activity table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ticket_activity (
            activity_id INT PRIMARY KEY AUTO_INCREMENT,
            ticket_id INT NOT NULL,
            user_id INT NOT NULL,
            activity TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)
    
    print("✓ Database tables created successfully!")
    
    # Create indexes
    cursor.execute("CREATE INDEX idx_tickets_employee ON tickets(employee_id)")
    cursor.execute("CREATE INDEX idx_tickets_assigned ON tickets(assigned_to)")
    cursor.execute("CREATE INDEX idx_tickets_status ON tickets(status)")
    cursor.execute("CREATE INDEX idx_tickets_priority ON tickets(priority)")
    cursor.execute("CREATE INDEX idx_activity_ticket ON ticket_activity(ticket_id)")
    
    print("✓ Indexes created successfully!")
    
    conn.commit()
    return conn, cursor

def populate_sample_data(conn, cursor):
    """Populate database with sample users and tickets"""
    
    # Hash passwords
    admin_pass = generate_password_hash('admin123')
    tech_pass = generate_password_hash('tech123')
    emp_pass = generate_password_hash('emp123')
    
    # Insert Admin
    cursor.execute("""
        INSERT INTO users (name, email, password, role, department) 
        VALUES (%s, %s, %s, %s, %s)
    """, ('Admin User', 'admin@abctech.com', admin_pass, 'Admin', 'IT'))
    
    print("✓ Admin user created (admin@abctech.com / admin123)")
    
    # Insert Technicians
    technicians = [
        ('John Network', 'john.tech@abctech.com', tech_pass, 'Technician', 'IT', 'Network', '555-0101'),
        ('Sarah Hardware', 'sarah.tech@abctech.com', tech_pass, 'Technician', 'IT', 'Hardware', '555-0102'),
        ('Mike Software', 'mike.tech@abctech.com', tech_pass, 'Technician', 'IT', 'Software', '555-0103'),
        ('Lisa Security', 'lisa.tech@abctech.com', tech_pass, 'Technician', 'IT', 'Security', '555-0104'),
        ('Tom General', 'tom.tech@abctech.com', tech_pass, 'Technician', 'IT', 'General', '555-0105'),
    ]
    
    for tech in technicians:
        cursor.execute("""
            INSERT INTO users (name, email, password, role, department, skill, phone)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, tech)
    
    print("✓ 5 Technicians created (*.tech@abctech.com / tech123)")
    
    # Insert Employees
    employees = [
        ('Alice Johnson', 'alice@abctech.com', emp_pass, 'Employee', 'Sales', '555-0201'),
        ('Bob Smith', 'bob@abctech.com', emp_pass, 'Employee', 'Marketing', '555-0202'),
        ('Carol Williams', 'carol@abctech.com', emp_pass, 'Employee', 'HR', '555-0203'),
        ('David Brown', 'david@abctech.com', emp_pass, 'Employee', 'Finance', '555-0204'),
        ('Emma Davis', 'emma@abctech.com', emp_pass, 'Employee', 'Sales', '555-0205'),
        ('Frank Miller', 'frank@abctech.com', emp_pass, 'Employee', 'Operations', '555-0206'),
        ('Grace Wilson', 'grace@abctech.com', emp_pass, 'Employee', 'Marketing', '555-0207'),
        ('Henry Taylor', 'henry@abctech.com', emp_pass, 'Employee', 'Finance', '555-0208'),
    ]
    
    for emp in employees:
        cursor.execute("""
            INSERT INTO users (name, email, password, role, department, phone)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, emp)
    
    print("✓ 8 Employees created (*.@abctech.com / emp123)")
    
    # Insert Sample Tickets
    sample_tickets = [
        (6, 'WiFi Not Connecting', 'My laptop is not connecting to office WiFi since morning. Shows authentication error. Need urgent help.', 'Network', 'High', 'Open', 2, 'Sales'),
        (7, 'Printer Not Working', 'The printer on 3rd floor is not printing. Paper jam error displayed.', 'Hardware', 'Medium', 'In Progress', 3, 'Marketing'),
        (8, 'MS Office Installation', 'Need Microsoft Office installed on my new laptop for project work.', 'Software', 'Low', 'Open', 4, 'HR'),
        (9, 'Password Reset Required', 'I forgot my email password and cannot access my account. Please help.', 'Security', 'High', 'Resolved', 5, 'Finance'),
        (10, 'Slow Computer', 'My system is running very slow. Takes 5 minutes to open applications.', 'Hardware', 'Medium', 'In Progress', 3, 'Sales'),
        (11, 'VPN Connection Issue', 'Cannot connect to company VPN from home. Getting timeout error.', 'Network', 'High', 'Open', 2, 'Operations'),
        (12, 'Software Update Failed', 'Windows update is stuck at 45%. System is not responding.', 'Software', 'Medium', 'Open', 4, 'Marketing'),
        (13, 'Screen Flickering', 'My monitor screen is flickering and showing vertical lines.', 'Hardware', 'Low', 'Open', 3, 'Finance'),
    ]
    
    for ticket in sample_tickets:
        cursor.execute("""
            INSERT INTO tickets (employee_id, title, description, category, priority, status, assigned_to, department)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, ticket)
        
        # Add initial activity
        ticket_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO ticket_activity (ticket_id, user_id, activity)
            VALUES (%s, %s, %s)
        """, (ticket_id, ticket[0], 'Ticket created'))
    
    print("✓ 8 Sample tickets created")
    
    conn.commit()
    print("\n✓ Database setup completed successfully!")
    print("\n" + "="*60)
    print("DEMO CREDENTIALS")
    print("="*60)
    print("\nAdmin Access:")
    print("  Email: admin@abctech.com")
    print("  Password: admin123")
    print("\nTechnician Access:")
    print("  Email: john.tech@abctech.com (Network Specialist)")
    print("  Email: sarah.tech@abctech.com (Hardware Technician)")
    print("  Email: mike.tech@abctech.com (Software Support)")
    print("  Email: lisa.tech@abctech.com (Security Expert)")
    print("  Password: tech123 (for all technicians)")
    print("\nEmployee Access:")
    print("  Email: alice@abctech.com")
    print("  Email: bob@abctech.com")
    print("  Password: emp123 (for all employees)")
    print("\n" + "="*60)

if __name__ == "__main__":
    try:
        print("\n" + "="*60)
        print("ABC TECH HELPDESK - DATABASE SETUP")
        print("="*60 + "\n")
        
        conn, cursor = create_database()
        populate_sample_data(conn, cursor)
        
        cursor.close()
        conn.close()
        
        print("\nYou can now run the application with: python app.py")
        print("="*60 + "\n")
        
    except Exception as e:
        print(f"\n✗ Error: {e}")
        print("\nPlease check your MySQL connection settings and try again.")
