# 🎫 ABC Tech Smart Helpdesk Ticketing System

## 📋 Project Overview

**Company Context:** ABC Tech Pvt Ltd  
**Employees:** 300+  
**IT Team:** 10 Technicians  
**Problem Statement:** Employees face frequent IT issues and email-based support is slow and inefficient.

**Solution:** A Smart AI-Powered Helpdesk Ticketing System that automatically categorizes tickets, assigns priority, and routes them to the right technician.

---

## 🌟 Key Features

### 1. **AI-Powered Ticket Categorization**
- Automatic categorization into: Hardware, Software, Network, Security, General
- Smart priority assignment: High, Medium, Low
- Uses NLP-based keyword analysis

### 2. **Auto-Assignment System**
- Tickets automatically assigned to technicians based on their skills
- Network issues → Network Specialist
- Hardware issues → Hardware Technician
- Software issues → Software Support
- Security issues → Security Expert

### 3. **Role-Based Dashboards**

#### Employee Dashboard
- Create and track tickets
- View ticket status in real-time
- See ticket history

#### Technician Dashboard
- View assigned tickets sorted by priority
- Update ticket status (Open → In Progress → Resolved)
- Add comments and notes
- Quick update functionality

#### Admin Dashboard
- Complete system overview
- Ticket analytics with charts
- Technician performance metrics
- Category and priority breakdowns
- SLA monitoring

### 4. **Real-Time Tracking**
- Ticket activity timeline
- Status updates
- Comment history
- Technician assignments

---

## 🛠️ Technology Stack

### Frontend
- **HTML5** - Structure
- **CSS3** with **Bootstrap 5** - Responsive Design
- **JavaScript** - Dynamic interactions
- **Chart.js** - Data visualization
- **Font Awesome** - Icons

### Backend
- **Python 3.8+** - Programming language
- **Flask** - Web framework
- **Flask-MySQLdb** - Database connector

### Database
- **MySQL** - Relational database

### AI/ML
- **NLP-based keyword analysis** - Smart categorization
- **Rule-based priority engine** - Automated priority assignment

---

## 📁 Project Structure

```
abc-tech-helpdesk/
│
├── app.py                      # Main Flask application
├── setup_database.py           # Database setup script
├── requirements.txt            # Python dependencies
├── database_schema.sql         # SQL schema
│
├── templates/                  # HTML templates
│   ├── base.html              # Base template
│   ├── login.html             # Login page
│   ├── employee_dashboard.html # Employee dashboard
│   ├── create_ticket.html     # Ticket creation form
│   ├── view_ticket.html       # Ticket details
│   ├── technician_dashboard.html # Technician dashboard
│   ├── admin_dashboard.html   # Admin dashboard
│   └── all_tickets.html       # All tickets view
│
└── static/
    └── css/
        └── style.css          # Custom styles
```

---

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- MySQL Server 8.0+
- pip (Python package manager)

### Step 1: Install MySQL
```bash
# For Ubuntu/Debian
sudo apt update
sudo apt install mysql-server

# For Windows
# Download from: https://dev.mysql.com/downloads/mysql/

# For macOS
brew install mysql
```

### Step 2: Clone/Download the Project
```bash
# Extract the project files to a directory
cd abc-tech-helpdesk
```

### Step 3: Install Python Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure MySQL
1. Start MySQL server:
```bash
# Ubuntu/Linux
sudo service mysql start

# macOS
mysql.server start

# Windows
# MySQL starts automatically
```

2. Set MySQL root password if needed:
```bash
mysql -u root -p
ALTER USER 'root'@'localhost' IDENTIFIED BY 'password';
FLUSH PRIVILEGES;
EXIT;
```

### Step 5: Update Database Configuration
Edit `app.py` and update MySQL credentials:
```python
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'your_password'  # Change this
app.config['MYSQL_DB'] = 'helpdesk_db'
```

Also update `setup_database.py`:
```python
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='your_password'  # Change this
)
```

### Step 6: Setup Database
```bash
python setup_database.py
```

This will:
- Create the `helpdesk_db` database
- Create all necessary tables
- Populate sample users and tickets
- Display demo credentials

### Step 7: Run the Application
```bash
python app.py
```

The application will start on `http://localhost:5000`

---

## 🔐 Demo Credentials

### Admin Access
- **Email:** admin@abctech.com
- **Password:** admin123
- **Access:** Full system control, analytics, reports

### Technician Access
- **Network Specialist:** john.tech@abctech.com / tech123
- **Hardware Technician:** sarah.tech@abctech.com / tech123
- **Software Support:** mike.tech@abctech.com / tech123
- **Security Expert:** lisa.tech@abctech.com / tech123

### Employee Access
- **Email:** alice@abctech.com / emp123
- **Email:** bob@abctech.com / emp123
- **Email:** carol@abctech.com / emp123
- **Email:** david@abctech.com / emp123

---

## 🎯 How It Works

### Employee Workflow
1. **Login** with company credentials
2. **Create Ticket** by describing the issue
3. **AI Analysis** automatically categorizes and prioritizes
4. **Auto-Assignment** to appropriate technician
5. **Track Status** through dashboard
6. **Receive Updates** as technician works on the issue

### AI Categorization Logic

```python
# Network Issues
Keywords: wifi, network, internet, connection, vpn, lan, ethernet

# Hardware Issues  
Keywords: laptop, printer, mouse, keyboard, monitor, hardware

# Software Issues
Keywords: software, install, application, program, office

# Security Issues
Keywords: password, security, virus, malware, access
```

### Priority Assignment Logic

```python
# High Priority
Keywords: urgent, critical, server down, not working, emergency

# Medium Priority
Keywords: slow, issue, problem, error

# Low Priority
Default for non-urgent issues

# Special Rule
Security issues are ALWAYS marked as High Priority
```

### Technician Workflow
1. **Login** to technician dashboard
2. **View assigned tickets** sorted by priority
3. **Update status**: Open → In Progress → Resolved
4. **Add comments** for communication
5. **Close ticket** when issue is resolved

### Admin Workflow
1. **Monitor all tickets** system-wide
2. **View analytics** with visual charts
3. **Check technician performance**
4. **Identify bottlenecks** and trends
5. **Generate reports**

---

## 📊 Database Schema

### Users Table
```sql
- user_id (Primary Key)
- name
- email (Unique)
- password (Hashed)
- role (Employee/Technician/Admin)
- department
- skill (for technicians)
- created_at
```

### Tickets Table
```sql
- ticket_id (Primary Key)
- employee_id (Foreign Key → users)
- title
- description
- category (Hardware/Software/Network/Security/General)
- priority (Low/Medium/High)
- status (Open/In Progress/Resolved/Closed)
- assigned_to (Foreign Key → users)
- department
- created_at
- updated_at
- resolved_at
```

### Ticket Activity Table
```sql
- activity_id (Primary Key)
- ticket_id (Foreign Key → tickets)
- user_id (Foreign Key → users)
- activity (text)
- created_at
```

---

## 🎨 Features Demonstration

### 1. Smart Ticket Creation
- Real-time AI preview of category and priority
- Example issues for quick ticket creation
- Helpful tips and guidance

### 2. Interactive Dashboards
- Color-coded statistics cards
- Quick action buttons
- Real-time data updates

### 3. Advanced Filtering (Admin)
- Filter by status, category, priority
- Search functionality
- Dynamic ticket counting

### 4. Performance Analytics
- Visual charts (pie, bar, doughnut)
- Technician performance metrics
- Resolution rate tracking

### 5. Activity Timeline
- Complete ticket history
- User actions tracking
- Time-stamped updates

---

## 🔧 Customization

### Adding New Categories
Edit `app.py`:
```python
category_keywords = {
    'Your_Category': ['keyword1', 'keyword2', ...]
}
```

### Adding New Technicians
```python
python
>>> from werkzeug.security import generate_password_hash
>>> print(generate_password_hash('password'))
```
Then insert into database with appropriate skill.

### Modifying AI Logic
Edit the `analyze_ticket()` function in `app.py` to customize:
- Category keywords
- Priority rules
- Assignment logic

---

## 📱 Responsive Design
- Mobile-friendly interface
- Tablet optimized
- Desktop full-featured
- Bootstrap 5 responsive grid

---

## 🔒 Security Features
- Password hashing with Werkzeug
- Session-based authentication
- Role-based access control
- SQL injection prevention with parameterized queries
- XSS protection

---

## 📈 Future Enhancements

1. **Email Notifications**
   - Send emails on ticket creation
   - Status change notifications
   - SLA breach alerts

2. **File Attachments**
   - Upload screenshots
   - Attach error logs
   - Document sharing

3. **Advanced Analytics**
   - Machine learning predictions
   - Trend analysis
   - Automated reporting

4. **SLA Management**
   - Response time tracking
   - Resolution time monitoring
   - Escalation rules

5. **Knowledge Base**
   - Common solutions library
   - Self-service portal
   - FAQ section

6. **Mobile App**
   - Native iOS/Android apps
   - Push notifications
   - Offline capability

---

## 🐛 Troubleshooting

### MySQL Connection Error
```
Error: Can't connect to MySQL server
Solution: Check if MySQL is running and credentials are correct
```

### Import Error
```
Error: No module named 'flask'
Solution: Run: pip install -r requirements.txt
```

### Database Already Exists
```
Solution: Drop existing database:
mysql -u root -p
DROP DATABASE helpdesk_db;
EXIT;
Then run: python setup_database.py
```

---

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the code comments
3. Verify database connections
4. Check Python version compatibility

---

## 👨‍💻 Developer Notes

### Code Structure
- **Modular design** for easy maintenance
- **Well-commented code** for understanding
- **Separation of concerns** (MVC pattern)
- **Reusable components**

### Best Practices Followed
- PEP 8 Python style guide
- Secure password storage
- Input validation
- Error handling
- Responsive design principles

---

## 📄 License

This project is created for educational purposes as part of an academic project for ABC Tech Pvt Ltd.

---

## 🙏 Acknowledgments

- Bootstrap team for the UI framework
- Chart.js for data visualization
- Font Awesome for icons
- Flask community for the web framework

---

## 📊 Project Statistics

- **Lines of Code:** ~2,500+
- **Files:** 15+
- **Database Tables:** 3
- **User Roles:** 3
- **Ticket Categories:** 5
- **Priority Levels:** 3
- **Status Types:** 4

---

**© 2024 ABC Tech Pvt Ltd - Smart Helpdesk System**

*Built with ❤️ for efficient IT support management*
