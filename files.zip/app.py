from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import re

app = Flask(__name__)
app.secret_key = 'abc_tech_secret_key_2024'

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'password'
app.config['MYSQL_DB'] = 'helpdesk_db'

mysql = MySQL(app)

# AI-Based Ticket Categorization and Priority Assignment
def analyze_ticket(description):
    """
    Smart AI logic to categorize tickets and assign priority
    based on keyword analysis
    """
    description_lower = description.lower()
    
    # Category Detection
    category = 'General'
    priority = 'Low'
    
    # Network Issues
    network_keywords = ['wifi', 'network', 'internet', 'connection', 'vpn', 'lan', 'ethernet', 'router']
    # Hardware Issues
    hardware_keywords = ['laptop', 'desktop', 'printer', 'mouse', 'keyboard', 'monitor', 'screen', 'hardware']
    # Software Issues
    software_keywords = ['software', 'application', 'install', 'update', 'program', 'app', 'windows', 'office']
    # Security Issues
    security_keywords = ['security', 'virus', 'malware', 'password', 'access', 'phishing', 'hack', 'breach']
    
    # Category Assignment
    if any(keyword in description_lower for keyword in network_keywords):
        category = 'Network'
    elif any(keyword in description_lower for keyword in hardware_keywords):
        category = 'Hardware'
    elif any(keyword in description_lower for keyword in software_keywords):
        category = 'Software'
    elif any(keyword in description_lower for keyword in security_keywords):
        category = 'Security'
    
    # Priority Assignment (Smart Logic)
    high_priority_keywords = ['urgent', 'critical', 'server down', 'not working', 'crashed', 'emergency', 'asap']
    medium_priority_keywords = ['slow', 'issue', 'problem', 'error', 'sometimes']
    
    if any(keyword in description_lower for keyword in high_priority_keywords):
        priority = 'High'
    elif any(keyword in description_lower for keyword in medium_priority_keywords):
        priority = 'Medium'
    else:
        priority = 'Low'
    
    # Special case: Security always High priority
    if category == 'Security':
        priority = 'High'
    
    return category, priority

# Auto-assign technician based on category and availability
def auto_assign_technician(category):
    """
    Smart assignment of technicians based on their skills
    """
    cur = mysql.connection.cursor()
    
    # Get available technicians with matching skill
    cur.execute("""
        SELECT user_id, name FROM users 
        WHERE role = 'Technician' AND skill = %s
        ORDER BY RAND() LIMIT 1
    """, (category,))
    
    technician = cur.fetchone()
    cur.close()
    
    if technician:
        return technician[0], technician[1]
    
    # If no specific skill match, assign to general technician
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT user_id, name FROM users 
        WHERE role = 'Technician'
        ORDER BY RAND() LIMIT 1
    """)
    technician = cur.fetchone()
    cur.close()
    
    if technician:
        return technician[0], technician[1]
    
    return None, None

# Routes

@app.route('/')
def index():
    if 'user_id' in session:
        if session['role'] == 'Employee':
            return redirect(url_for('employee_dashboard'))
        elif session['role'] == 'Technician':
            return redirect(url_for('technician_dashboard'))
        elif session['role'] == 'Admin':
            return redirect(url_for('admin_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()
        
        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['name'] = user[1]
            session['email'] = user[2]
            session['role'] = user[4]
            session['department'] = user[5]
            
            flash('Login successful!', 'success')
            
            if user[4] == 'Employee':
                return redirect(url_for('employee_dashboard'))
            elif user[4] == 'Technician':
                return redirect(url_for('technician_dashboard'))
            elif user[4] == 'Admin':
                return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid email or password!', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Employee Routes

@app.route('/employee/dashboard')
def employee_dashboard():
    if 'user_id' not in session or session['role'] != 'Employee':
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    
    # Get employee's tickets
    cur.execute("""
        SELECT ticket_id, title, category, priority, status, created_at 
        FROM tickets 
        WHERE employee_id = %s 
        ORDER BY created_at DESC
    """, (session['user_id'],))
    tickets = cur.fetchall()
    
    # Get statistics
    cur.execute("SELECT COUNT(*) FROM tickets WHERE employee_id = %s", (session['user_id'],))
    total_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE employee_id = %s AND status = 'Open'", (session['user_id'],))
    open_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE employee_id = %s AND status = 'Resolved'", (session['user_id'],))
    resolved_tickets = cur.fetchone()[0]
    
    cur.close()
    
    return render_template('employee_dashboard.html', 
                          tickets=tickets,
                          total_tickets=total_tickets,
                          open_tickets=open_tickets,
                          resolved_tickets=resolved_tickets)

@app.route('/employee/create-ticket', methods=['GET', 'POST'])
def create_ticket():
    if 'user_id' not in session or session['role'] != 'Employee':
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        department = session['department']
        
        # AI Analysis
        category, priority = analyze_ticket(description)
        
        # Auto-assign technician
        tech_id, tech_name = auto_assign_technician(category)
        
        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO tickets (employee_id, title, description, category, priority, status, assigned_to, department, created_at)
            VALUES (%s, %s, %s, %s, %s, 'Open', %s, %s, %s)
        """, (session['user_id'], title, description, category, priority, tech_id, department, datetime.now()))
        mysql.connection.commit()
        
        ticket_id = cur.lastrowid
        
        # Log activity
        cur.execute("""
            INSERT INTO ticket_activity (ticket_id, user_id, activity, created_at)
            VALUES (%s, %s, %s, %s)
        """, (ticket_id, session['user_id'], 'Ticket created', datetime.now()))
        mysql.connection.commit()
        cur.close()
        
        flash(f'Ticket created successfully! Category: {category}, Priority: {priority}, Assigned to: {tech_name}', 'success')
        return redirect(url_for('employee_dashboard'))
    
    return render_template('create_ticket.html')

@app.route('/employee/ticket/<int:ticket_id>')
def view_ticket(ticket_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    
    # Get ticket details
    cur.execute("""
        SELECT t.*, u.name as employee_name, tech.name as technician_name
        FROM tickets t
        LEFT JOIN users u ON t.employee_id = u.user_id
        LEFT JOIN users tech ON t.assigned_to = tech.user_id
        WHERE t.ticket_id = %s
    """, (ticket_id,))
    ticket = cur.fetchone()
    
    # Get ticket activity
    cur.execute("""
        SELECT ta.*, u.name as user_name
        FROM ticket_activity ta
        LEFT JOIN users u ON ta.user_id = u.user_id
        WHERE ta.ticket_id = %s
        ORDER BY ta.created_at DESC
    """, (ticket_id,))
    activities = cur.fetchall()
    
    cur.close()
    
    return render_template('view_ticket.html', ticket=ticket, activities=activities)

# Technician Routes

@app.route('/technician/dashboard')
def technician_dashboard():
    if 'user_id' not in session or session['role'] != 'Technician':
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    
    # Get assigned tickets
    cur.execute("""
        SELECT t.ticket_id, t.title, t.category, t.priority, t.status, t.created_at, u.name as employee_name, u.department
        FROM tickets t
        LEFT JOIN users u ON t.employee_id = u.user_id
        WHERE t.assigned_to = %s
        ORDER BY 
            CASE t.priority 
                WHEN 'High' THEN 1
                WHEN 'Medium' THEN 2
                WHEN 'Low' THEN 3
            END,
            t.created_at ASC
    """, (session['user_id'],))
    tickets = cur.fetchall()
    
    # Get statistics
    cur.execute("SELECT COUNT(*) FROM tickets WHERE assigned_to = %s", (session['user_id'],))
    total_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE assigned_to = %s AND status = 'Open'", (session['user_id'],))
    open_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE assigned_to = %s AND status = 'In Progress'", (session['user_id'],))
    in_progress_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE assigned_to = %s AND status = 'Resolved'", (session['user_id'],))
    resolved_tickets = cur.fetchone()[0]
    
    cur.close()
    
    return render_template('technician_dashboard.html', 
                          tickets=tickets,
                          total_tickets=total_tickets,
                          open_tickets=open_tickets,
                          in_progress_tickets=in_progress_tickets,
                          resolved_tickets=resolved_tickets)

@app.route('/technician/update-ticket/<int:ticket_id>', methods=['POST'])
def update_ticket(ticket_id):
    if 'user_id' not in session or session['role'] != 'Technician':
        return redirect(url_for('login'))
    
    status = request.form['status']
    comment = request.form.get('comment', '')
    
    cur = mysql.connection.cursor()
    
    # Update ticket status
    cur.execute("""
        UPDATE tickets SET status = %s, updated_at = %s
        WHERE ticket_id = %s
    """, (status, datetime.now(), ticket_id))
    
    # Add comment if provided
    if comment:
        cur.execute("""
            INSERT INTO ticket_activity (ticket_id, user_id, activity, created_at)
            VALUES (%s, %s, %s, %s)
        """, (ticket_id, session['user_id'], f'Status updated to {status}. Comment: {comment}', datetime.now()))
    else:
        cur.execute("""
            INSERT INTO ticket_activity (ticket_id, user_id, activity, created_at)
            VALUES (%s, %s, %s, %s)
        """, (ticket_id, session['user_id'], f'Status updated to {status}', datetime.now()))
    
    mysql.connection.commit()
    cur.close()
    
    flash('Ticket updated successfully!', 'success')
    return redirect(url_for('technician_dashboard'))

# Admin Routes

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or session['role'] != 'Admin':
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    
    # Overall statistics
    cur.execute("SELECT COUNT(*) FROM tickets")
    total_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Open'")
    open_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'In Progress'")
    in_progress_tickets = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Resolved'")
    resolved_tickets = cur.fetchone()[0]
    
    # Category breakdown
    cur.execute("""
        SELECT category, COUNT(*) as count
        FROM tickets
        GROUP BY category
    """)
    category_stats = cur.fetchall()
    
    # Priority breakdown
    cur.execute("""
        SELECT priority, COUNT(*) as count
        FROM tickets
        GROUP BY priority
    """)
    priority_stats = cur.fetchall()
    
    # Recent tickets
    cur.execute("""
        SELECT t.ticket_id, t.title, t.category, t.priority, t.status, t.created_at, 
               u.name as employee_name, tech.name as technician_name
        FROM tickets t
        LEFT JOIN users u ON t.employee_id = u.user_id
        LEFT JOIN users tech ON t.assigned_to = tech.user_id
        ORDER BY t.created_at DESC
        LIMIT 10
    """)
    recent_tickets = cur.fetchall()
    
    # Technician performance
    cur.execute("""
        SELECT u.name, 
               COUNT(t.ticket_id) as total_tickets,
               SUM(CASE WHEN t.status = 'Resolved' THEN 1 ELSE 0 END) as resolved_tickets
        FROM users u
        LEFT JOIN tickets t ON u.user_id = t.assigned_to
        WHERE u.role = 'Technician'
        GROUP BY u.user_id, u.name
    """)
    technician_performance = cur.fetchall()
    
    cur.close()
    
    return render_template('admin_dashboard.html',
                          total_tickets=total_tickets,
                          open_tickets=open_tickets,
                          in_progress_tickets=in_progress_tickets,
                          resolved_tickets=resolved_tickets,
                          category_stats=category_stats,
                          priority_stats=priority_stats,
                          recent_tickets=recent_tickets,
                          technician_performance=technician_performance)

@app.route('/admin/all-tickets')
def all_tickets():
    if 'user_id' not in session or session['role'] != 'Admin':
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    
    cur.execute("""
        SELECT t.ticket_id, t.title, t.category, t.priority, t.status, t.created_at,
               u.name as employee_name, u.department, tech.name as technician_name
        FROM tickets t
        LEFT JOIN users u ON t.employee_id = u.user_id
        LEFT JOIN users tech ON t.assigned_to = tech.user_id
        ORDER BY t.created_at DESC
    """)
    tickets = cur.fetchall()
    
    cur.close()
    
    return render_template('all_tickets.html', tickets=tickets)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
